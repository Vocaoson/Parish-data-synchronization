<title> Example </title>
<meta charset="utf-8">
<script type="text/javascript" src="<?= base_url() ?>SupportWeb/vendor/bootstrap.js"></script>
<script type="text/javascript" src="<?= base_url() ?>SupportWeb/1.js"></script>
<link rel="stylesheet" href="<?= base_url() ?>SupportWeb/vendor/bootstrap.css">
<link rel="stylesheet" href="<?= base_url() ?>SupportWeb/1.css">
<link rel="stylesheet" href="<?= base_url() ?>SupportWeb/css/all.css">