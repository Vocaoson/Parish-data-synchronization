<title> Example </title>
<meta charset="utf-8">
<link rel="stylesheet" href="<?= base_url() ?>SupportWeb/vendor/bootstrap.css">
<link rel="stylesheet" href="<?= base_url() ?>SupportWeb/1.css">
<link rel="stylesheet" href="<?= base_url() ?>SupportWeb/css/all.css">