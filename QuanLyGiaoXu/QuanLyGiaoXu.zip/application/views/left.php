<div class="brand">
<h4>Quản lý giáo xứ</h4>
		</div>
<div class="contain-menu">
<!-- 	<p class=""><i class="fa fa-home "></i> Giáo phận</p>
	<p class=""><i class="fa fa-university "></i> Giáo hạt</p> -->
	<li class="btnGX files"><i class="fa fa-church"></i> <a href="#">File backup</a></li>
	<li class="btnGX"><i class="fa fa-user"></i> <a href="#">Quản lý</a><i class="fa fa-chevron-down down-management"></i></li>
	<div id="child-management">
	<li class="btnGX child-menu" id="management"><i class="fa fa-allergies"></i> <a href="#">Yêu cầu</a></li>
	<li class="btnGX child-menu"><i class="fa fa-user-edit"></i> <a href="#">Giáo xứ</a></li>
	</div>
</div>