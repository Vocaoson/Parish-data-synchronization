        <nav class="navbar navbar-light bg-faded ">
        	<button class="navbar-toggler hidden-sm-up" type="button" data-toggle="collapse" data-target="#exCollapsingNavbar2">
        	</button>

        	<div class="collapse navbar-toggleable-xs" id="exCollapsingNavbar2">

        		<a class="navbar-brand" href="#"></a>

        		<ul class="nav navbar-nav float-sm-right">

        			<li class="nav-item active">

        				<a class="nav-link" href="#">Admin <span class="sr-only">(current)</span></a>

        			</li>

        		</ul>

        	</div>
        </nav>
                